## Callbacks

This gives you the ability to listen for any changes and perform your own actions.

#### onLoad
Runs immediately after initialization.

> **type**: `attachable`

---

#### onNavigation
Runs after month change.

> **type**: `attachable`

---

#### onSelect
Runs on select the day.

> **type**: `attachable`

---

#### onClear
Runs on clear calendar.

> **type**: `attachable`

