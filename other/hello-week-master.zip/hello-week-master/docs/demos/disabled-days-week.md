## Disabled Days Week

#### Overview
Set disabled specific days of week.

#### HTML Structure
```html
<div class="hello-week"></div>
```

#### Javascript Initialization
```js
new HelloWeek({
    disabledDaysOfWeek: [0, 1] // disabling weekends
});
```

