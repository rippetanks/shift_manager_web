## Disabled Dates

#### Overview
Set disabled specific day/days.

#### HTML Structure
```html
<div class="hello-week"></div>
```

#### Javascript Initialization
```js
new HelloWeek({
    disableDates: [["2019-03-02", "2019-03-12"]]
});
```

